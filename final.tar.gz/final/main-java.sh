#!/bin/bash

java Main "$@"
