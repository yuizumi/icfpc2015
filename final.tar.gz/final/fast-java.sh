#!/bin/bash

java Greedy "$@"
