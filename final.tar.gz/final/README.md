Building and Running
--------------------

It's as simple as you'd expected.

    $ make ; ./play_icfp2015 -f input.json ...

Our programs were developed on MacOS X but should build and run on any Unix-
style system with bash, gcc(g++), make, and python.



Source Tree
-----------

The entire system can be found on <https://github.com/yuizumi/icfpc2015>.
