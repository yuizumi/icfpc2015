# icfpc2015

[@alotofwe](https://twitter.com/alotofwe),
[@cocodrips](https://twitter.com/cocodrips),
[@eomole](https://twitter.com/eomole),
[@tayama0324](https://twitter.com/tayama0324),
[@yuizumi_y5i](https://twitter.com/yuizumi_y5i)

wiki https://github.com/yuizumi/icfpc2015/wiki
